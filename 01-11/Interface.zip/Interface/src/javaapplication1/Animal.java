/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author alunodev08
 */
public abstract class Animal extends SerVivo{
   int numPatas;
   char sexo;

//     abstract void tratar();
//   void tratar(){
//       System.out.println("Animal: tratar() - ?????");
//   }
   
     abstract void falar();
//   void falar(){
//       System.out.println("Animal: falar() - ?????");
//   }
   
   void respirar(){
       System.out.println("Animal: respirar() - AR"); 
   }
   void mover(){
       System.out.println("Animal: mover()");
   }
   
}
