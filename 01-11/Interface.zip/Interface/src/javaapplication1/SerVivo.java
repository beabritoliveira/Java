/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author alunodev08
 */
public class SerVivo {
    int tamanho;

    @Override
    public String toString() {
        return "!! -- SerVivo{" + "tamanho=" + tamanho + '}';
    }
    
    void nascer(){
        System.out.println("SerVivo: nascer()"); 
    }
    
    void crescer(){
        System.out.println("SerVivo: crescer()"); 
    }
    
    void morrer(){
        System.out.println("SerVivo: morrer()"); 
    }
    
}
