/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author alunodev08
 */
public class Zoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println(" == SerVivo ==");
        SerVivo sv = new SerVivo();
        sv.nascer();
        sv.crescer();
        sv.morrer();
        
/*        
        System.out.println(" == Animal ==");
        Animal an = new Animal();
        an.mover();
        an.respirar();
        an.nascer();
        an.crescer();
        an.morrer();
*/        
        System.out.println(" == Mamifero ==");
        Mamifero ma = new Mamifero();
        ma.nascer();
        ma.crescer();
        ma.morrer();
        ma.mover();
        ma.respirar();

        System.out.println(" == Peixe ==");
        Peixe px = new Peixe();
        px.nascer();
        px.mover();
        px.respirar();
        px.falar();
        px.tratar();
        
        System.out.println(" == Ave ==");    
        Ave av = new Ave();
        av.falar();
        
    
    
/*    
    System.out.println(" == sobreescrita ==");
    sv.tamanho = 10;
    System.out.println(sv.tamanho);
    System.out.println(sv);
*/
    }
    
}
