/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author alunodev08
 */
public class Peixe extends Animal implements Pet{
   void respirar(){
       System.out.println("Peixe: respirar() - AGUA"); 
   }
   
    @Override
    void falar() {
      System.out.println("Peixe: falar() - GLUP GLUP");  
    }

    @Override
    public void tratar() {
      System.out.println("Peixe: tratar() - dando banho");
    }
   
   
}
